(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const state = {
    domain: '',
    profile: null,
    diagnostics: null,
    settings: {},
    threatReport: null
  };

  /* ============================================================
     DOM HELPERS — Trusted-Types / XSS safe
     ------------------------------------------------------------
     Every DOM node in this file is built with createElement +
     textContent. There is deliberately no innerHTML anywhere — the
     popup renders strings that come from third-party APIs (VT engine
     names, heuristic messages, saved domain names) and HTML-escaping
     by hand is easy to get subtly wrong. The DOM API makes escaping
     structurally impossible.
     ============================================================ */
  function el(tag, opts = {}) {
    const node = document.createElement(tag);
    if (opts.className) node.className = opts.className;
    if (opts.text != null) node.textContent = String(opts.text);
    if (opts.style) {
      if (typeof opts.style === 'string') {
        try { node.setAttribute('style', opts.style); } catch {}
      } else {
        for (const [k, v] of Object.entries(opts.style)) {
          try { node.style[k] = v; } catch {}
        }
      }
    }
    if (opts.attrs) {
      for (const [k, v] of Object.entries(opts.attrs)) {
        try { node.setAttribute(k, String(v)); } catch {}
      }
    }
    if (opts.children) {
      for (const c of opts.children) {
        if (c) node.appendChild(c);
      }
    }
    if (opts.on) {
      for (const [evt, handler] of Object.entries(opts.on)) {
        node.addEventListener(evt, handler);
      }
    }
    return node;
  }

  function clearNode(node) {
    if (!node) return;
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  /* ============================================================
     TOAST
     ============================================================ */
  function showToast(message, type = 'success') {
    const container = $('toastContainer');
    if (!container) return;
    const toast = el('div', { className: `toast ${type}` });
    toast.appendChild(el('span', { text: type === 'success' ? '✓' : '⚠' }));
    toast.appendChild(el('span', { text: String(message || '') }));
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  /* ============================================================
     HELPERS
     ============================================================ */
  function normalizeHost(raw) {
    try {
      const u = new URL(raw);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
      return u.hostname.toLowerCase().replace(/\.$/, '');
    } catch { return ''; }
  }

  function send(message) {
    return chrome.runtime.sendMessage(message).then(res => {
      if (!res || !res.ok) throw new Error(res?.error || 'Request failed');
      return res;
    });
  }

  async function activeDomain() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return normalizeHost(tabs[0]?.url || '');
  }

  /* ============================================================
     THREAT INTEL — DOM API only
     ============================================================ */
  function renderThreatStatus(report) {
    const statusEl = $('threatStatus');
    const statsEl = $('threatStats');
    const fillEl = $('riskBarFill');
    const pctEl = $('riskPercentText');
    const flagsEl = $('vtEnginesDetected');
    if (!statusEl || !statsEl) return;

    clearNode(statusEl);

    if (!report) {
      statusEl.appendChild(el('span', { text: 'Not analyzed yet' }));
      statsEl.textContent = 'Click "Analyze" to query VirusTotal.';
      if (fillEl) fillEl.style.width = '0%';
      if (pctEl) { pctEl.textContent = '0% Risk'; pctEl.style.color = 'var(--accent)'; }
      if (flagsEl) { clearNode(flagsEl); flagsEl.appendChild(el('span', { text: 'No data available' })); }
      return;
    }

    if (report.error) {
      statusEl.appendChild(el('span', { style: { color: '#f87171' }, text: '⚠ ' + String(report.error) }));
      statsEl.textContent = '—';
      return;
    }

    const risk = Number(report.riskPercentage) || 0;
    const verdict = String(report.verdict || report.status || 'unknown').toLowerCase();

    if (fillEl) fillEl.style.width = `${risk}%`;
    if (pctEl) pctEl.textContent = `${risk}% Risk`;

    let color = '#10b981', fillColor = '#10b981';
    if (verdict === 'malicious') { color = '#f87171'; fillColor = '#f43f5e'; }
    else if (verdict === 'suspicious') { color = '#fbbf24'; fillColor = '#f59e0b'; }
    else if (report.status === 'allowlisted') { color = '#60a5fa'; fillColor = '#3b82f6'; }

    if (fillEl) fillEl.style.background = fillColor;
    if (pctEl) pctEl.style.color = color;

    if (report.status === 'allowlisted') {
      statusEl.appendChild(el('span', { style: { color: '#34d399' }, text: '✓ Trusted Site (Whitelisted)' }));
      statsEl.textContent = 'Verified high-reputation domain — no VT quota used.';
      if (flagsEl) {
        clearNode(flagsEl);
        flagsEl.appendChild(el('span', { style: { color: '#34d399' }, text: '✓ On trusted allowlist' }));
      }
      return;
    }

    if (verdict === 'malicious') {
      const malCount = Number(report.stats?.malicious) || 0;
      statusEl.appendChild(el('span', {
        style: { color: '#f87171', fontWeight: 'bold' },
        text: `⚠ Malicious (${malCount} engines)`
      }));
    } else if (verdict === 'suspicious') {
      const susCount = Number(report.stats?.suspicious) || 0;
      statusEl.appendChild(el('span', {
        style: { color: '#fbbf24' },
        text: `⚡ Suspicious (${susCount} engines)`
      }));
    } else if (verdict === 'clean') {
      statusEl.appendChild(el('span', { style: { color: '#34d399' }, text: '✓ Clean' }));
    } else {
      statusEl.appendChild(el('span', { text: `Unknown (${report.status || 'unrated'})` }));
    }

    if (flagsEl) {
      clearNode(flagsEl);
      const engines = Array.isArray(report.flaggedEngines) ? report.flaggedEngines : [];
      if (engines.length) {
        const prefix = verdict === 'malicious' ? '⚠ Flagged by: ' : '⚡ Flagged by: ';
        flagsEl.appendChild(el('strong', { style: { color }, text: prefix }));
        const list = engines.slice(0, 6).join(', ');
        const more = engines.length > 6 ? ` +${engines.length - 6} more` : '';
        flagsEl.appendChild(document.createTextNode(list + more));
      } else if (verdict === 'clean') {
        flagsEl.appendChild(el('span', {
          style: { color: '#34d399' },
          text: '✓ 0 / 70+ Antivirus Engines flagged this site'
        }));
      } else {
        flagsEl.appendChild(el('span', { text: 'Not yet indexed by VirusTotal' }));
      }

      if (Array.isArray(report.heuristicSignals) && report.heuristicSignals.length) {
        const heur = report.heuristicSignals
          .map(s => s.message || s.kind)
          .slice(0, 2)
          .join(' • ');
        flagsEl.appendChild(el('div', {
          style: { marginTop: '4px', color: '#fbbf24' },
          text: `🧠 ${heur}`
        }));
      }
    }

    const harmless = Number(report.stats?.harmless) || 0;
    const malicious = Number(report.stats?.malicious) || 0;
    const suspicious = Number(report.stats?.suspicious) || 0;
    statsEl.textContent = `Harmless: ${harmless} • Malicious: ${malicious} • Suspicious: ${suspicious}`;
  }

  function renderAutoArmBadge() {
    // Add an inline badge to the VT card when the current host was
    // auto-armed. Rendered separately from renderThreatStatus so that
    // re-running the threat query does not stomp on the badge.
    const card = document.querySelector('.vt-card');
    if (!card) return;

    let badge = card.querySelector('.auto-arm-badge');
    const profile = state.profile;
    const isAutoArmed = profile?.autoArmed === true;

    if (!isAutoArmed) {
      if (badge) badge.remove();
      return;
    }

    if (!badge) {
      badge = el('div', { className: 'auto-arm-badge' });
      card.appendChild(badge);
    }
    clearNode(badge);
    badge.appendChild(el('span', { text: '⚡ Auto-Armed — ' }));
    badge.appendChild(el('span', {
      className: 'auto-arm-reason',
      text: profile.autoArmReason || 'triggered by threat scan'
    }));
  }

  async function loadThreatIntel() {
    if (!state.domain) return;
    const btn = $('scanDomainBtn');
    if (btn) btn.disabled = false;

    try {
      const res = await send({ type: 'get-threat-intel', domain: state.domain });
      let report = res?.report;

      if (!report && state.settings.threatIntelEnabled && state.settings.threatIntelAutoScan) {
        renderThreatStatus({ status: 'analyzing', riskPercentage: 0, verdict: 'unknown' });
        try {
          const q = await send({ type: 'query-threat-intel', domain: state.domain, force: false });
          report = q?.report;
        } catch {}
      }

      state.threatReport = report;
      renderThreatStatus(report);
      renderAutoArmBadge();
    } catch {
      renderThreatStatus({ error: 'Threat intelligence offline' });
    }
  }

  /* ============================================================
     PROFILE / SHIELD BUTTON
     ============================================================ */
  function renderProfile() {
    const profile = state.profile;
    const isArmed = Boolean(profile?.protected === true && profile?.mode === 'fortress');
    const btn = $('instantShieldBtn');
    const btnText = $('shieldBtnText');
    const stateEl = $('profileState');

    if (stateEl) {
      if (isArmed && profile?.autoArmed === true) {
        stateEl.textContent = '⚡ Auto-Armed: Popups blocked, navigation isolated';
      } else if (isArmed) {
        stateEl.textContent = '🛡️ Fortress Active: Popups blocked, navigation isolated';
      } else {
        stateEl.textContent = 'Vulnerable: Default protection. Click to lock site';
      }
    }

    if (btn && btnText) {
      btn.disabled = !state.domain;
      if (isArmed) {
        btn.className = 'shield-btn armed';
        btnText.textContent = 'Disarm Fortress';
      } else {
        btn.className = 'shield-btn';
        btnText.textContent = 'Add & Arm Fortress';
      }
    }

    renderBlockedDestinations();
    renderAutoArmBadge();
  }

  function renderBlockedDestinations() {
    const list = $('blockedList');
    if (!list) return;
    clearNode(list);

    const blocked = Array.isArray(state.profile?.blockedDestinationDomains)
      ? state.profile.blockedDestinationDomains
      : [];

    if (blocked.length === 0) {
      list.appendChild(el('div', {
        style: { color: 'var(--text-muted)', fontSize: '11px', padding: '4px 0' },
        text: 'No blocked destinations.'
      }));
      return;
    }

    for (const host of blocked) {
      const item = el('div', { className: 'blocked-item' });
      item.appendChild(el('span', { text: host }));
      item.appendChild(el('button', {
        text: '✕',
        attrs: { title: 'Remove block', 'aria-label': `Remove block for ${host}` },
        on: { click: () => removeBlock(host) }
      }));
      list.appendChild(item);
    }
  }

  /* ============================================================
     AUTO-ARM CONTROLS
     ============================================================ */
  function renderAutoArmControls() {
    const toggle = $('autoArmToggle');
    const armSlider = $('armThreshold');
    const blockSlider = $('blockThreshold');
    const armVal = $('armThresholdValue');
    const blockVal = $('blockThresholdValue');

    const enabled = state.settings.autoArmFortress !== false;
    const armThreshold = Number.isFinite(state.settings.autoArmFortressThreshold)
      ? state.settings.autoArmFortressThreshold
      : 10;
    const blockThreshold = Number.isFinite(state.settings.autoBlockThreshold)
      ? state.settings.autoBlockThreshold
      : 70;

    if (toggle) {
      toggle.textContent = enabled ? 'ON' : 'OFF';
      toggle.className = `status-badge ${enabled ? 'on' : 'off'}`;
    }
    if (armSlider) armSlider.value = String(armThreshold);
    if (blockSlider) blockSlider.value = String(blockThreshold);
    if (armVal) armVal.textContent = `${armThreshold}%`;
    if (blockVal) blockVal.textContent = `${blockThreshold}%`;
  }

  async function persistThreshold(key, value) {
    try {
      const res = await send({ type: 'patch-settings', patch: { [key]: value } });
      state.settings = res.settings || state.settings;
      return true;
    } catch (err) {
      showToast(err.message, 'error');
      return false;
    }
  }

  /* ============================================================
     REFRESH
     ============================================================ */
  async function refresh() {
    try {
      state.domain = await activeDomain();
      const domainEl = $('domain');
      if (domainEl) domainEl.textContent = state.domain || 'Unsupported page';

      if (!state.domain) {
        state.profile = null;
        renderProfile();
        return;
      }

      const [profileResult, diagResult, settingsResult] = await Promise.all([
        send({ type: 'get-profile', domain: state.domain }),
        send({ type: 'get-diagnostics' }),
        send({ type: 'get-settings' })
      ]);

      state.profile = profileResult.profile;
      state.diagnostics = diagResult.diagnostics;
      state.settings = settingsResult.settings || {};

      if (state.settings.threatIntelEnabled && state.settings.threatIntelAutoScan) {
        const cached = await send({ type: 'get-threat-intel', domain: state.domain }).catch(() => null);
        if (!cached?.report) {
          send({ type: 'query-threat-intel', domain: state.domain, force: false }).catch(() => {});
        }
      }

      const resolverBtn = $('resolver');
      if (resolverBtn) {
        const on = state.settings.resolverEnabled === true;
        resolverBtn.textContent = on ? 'ON' : 'OFF';
        resolverBtn.className = `status-badge ${on ? 'on' : 'off'}`;
      }

      if ($('dnrCount')) $('dnrCount').textContent = String(state.diagnostics?.dnrRuleCount || 0);
      if ($('graphCount')) $('graphCount').textContent = String(state.diagnostics?.graphNodeCount || 0);
      if ($('profileCount')) $('profileCount').textContent = String(state.diagnostics?.profileCount || 0);

      renderProfile();
      renderAutoArmControls();
      await loadThreatIntel();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  /* ============================================================
     ACTIONS
     ============================================================ */
  async function toggleInstantShield() {
    if (!state.domain) return;
    const isArmed = Boolean(state.profile?.protected === true && state.profile?.mode === 'fortress');
    const patch = isArmed
      ? { protected: false, mode: 'standard', autoArmed: false }
      : { protected: true, mode: 'fortress', autoContainRedirects: true, clickbaitGuard: true };

    try {
      const res = await send({ type: 'patch-profile', domain: state.domain, patch });
      state.profile = res.profile;
      renderProfile();
      showToast(isArmed ? 'Fortress Disarmed.' : '⚡ Domain added & Fortress Armed!');
      await refresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function addBlock() {
    if (!state.domain) return;
    const input = $('destination');
    const destination = normalizeHost(input?.value?.trim() || '');
    if (!destination) {
      showToast('Enter a valid destination domain', 'error');
      return;
    }
    try {
      const current = Array.isArray(state.profile?.blockedDestinationDomains)
        ? state.profile.blockedDestinationDomains
        : [];
      const blocked = [...new Set([...current, destination])].slice(0, 1000);
      const res = await send({
        type: 'patch-profile',
        domain: state.domain,
        patch: { protected: true, mode: 'fortress', blockedDestinationDomains: blocked }
      });
      state.profile = res.profile;
      if (input) input.value = '';
      showToast(`Blocked ${destination}`);
      await refresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function removeBlock(destination) {
    if (!state.domain || !state.profile) return;
    try {
      const blocked = (state.profile.blockedDestinationDomains || []).filter(x => x !== destination);
      const res = await send({
        type: 'patch-profile',
        domain: state.domain,
        patch: { blockedDestinationDomains: blocked }
      });
      state.profile = res.profile;
      showToast(`Removed ${destination}`);
      await refresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  /* ============================================================
     EVENT WIRING
     ============================================================ */
  $('instantShieldBtn')?.addEventListener('click', toggleInstantShield);
  $('addBlock')?.addEventListener('click', addBlock);
  $('destination')?.addEventListener('keydown', e => { if (e.key === 'Enter') addBlock(); });

  $('refreshBtn')?.addEventListener('click', async () => {
    await refresh();
    showToast('State synced.');
  });

  $('scanDomainBtn')?.addEventListener('click', async () => {
    if (!state.domain) return;
    const btn = $('scanDomainBtn');
    if (btn) btn.disabled = true;
    showToast('VirusTotal scan requested (rate-limit active)…');
    try {
      const res = await send({ type: 'query-threat-intel', domain: state.domain, force: true });
      if (res?.ok) {
        await loadThreatIntel();
        showToast('VirusTotal analysis updated!');
      }
    } catch (err) {
      showToast(err.message === 'no-api-key' ? 'Set VirusTotal API Key in Dashboard!' : err.message, 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  });

  $('resolver')?.addEventListener('click', async () => {
    const next = state.settings.resolverEnabled !== true;
    try {
      const res = await send({ type: 'patch-settings', patch: { resolverEnabled: next } });
      state.settings = res.settings;
      const on = state.settings.resolverEnabled === true;
      $('resolver').textContent = on ? 'ON' : 'OFF';
      $('resolver').className = `status-badge ${on ? 'on' : 'off'}`;
      showToast(`Redirect Resolver ${on ? 'Enabled' : 'Disabled'}`);
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  $('autoArmToggle')?.addEventListener('click', async () => {
    const next = state.settings.autoArmFortress === false;
    const ok = await persistThreshold('autoArmFortress', next);
    if (ok) {
      renderAutoArmControls();
      showToast(`Auto-Arm ${next ? 'Enabled' : 'Disabled'}`);
    }
  });

  $('armThreshold')?.addEventListener('input', () => {
    const v = $('armThreshold').value;
    if ($('armThresholdValue')) $('armThresholdValue').textContent = `${v}%`;
  });
  $('armThreshold')?.addEventListener('change', async () => {
    const v = Math.max(1, Math.min(100, Number($('armThreshold').value) || 10));
    const ok = await persistThreshold('autoArmFortressThreshold', v);
    if (ok) showToast(`Arm threshold → ${v}%`);
  });

  $('blockThreshold')?.addEventListener('input', () => {
    const v = $('blockThreshold').value;
    if ($('blockThresholdValue')) $('blockThresholdValue').textContent = `${v}%`;
  });
  $('blockThreshold')?.addEventListener('change', async () => {
    const v = Math.max(1, Math.min(100, Number($('blockThreshold').value) || 70));
    const ok = await persistThreshold('autoBlockThreshold', v);
    if (ok) showToast(`Block threshold → ${v}%`);
  });

  $('openDashboard')?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') }).catch(() => {});
  });

  /* ============================================================
     THEME
     ============================================================ */
  $('theme')?.addEventListener('click', async () => {
    const current = (await chrome.storage.local.get('theme')).theme || 'dark';
    const next = current === 'light' ? 'dark' : 'light';
    await chrome.storage.local.set({ theme: next });
    document.body.dataset.theme = next;
    const btn = $('theme');
    if (btn) btn.textContent = next === 'light' ? '🌙' : '☀';
  });

  chrome.storage.local.get('theme').then(({ theme = 'dark' }) => {
    document.body.dataset.theme = theme;
    const btn = $('theme');
    if (btn) btn.textContent = theme === 'light' ? '🌙' : '☀';
  }).catch(() => {});

  /* ============================================================
     BOOT
     ============================================================ */
  refresh();
})();