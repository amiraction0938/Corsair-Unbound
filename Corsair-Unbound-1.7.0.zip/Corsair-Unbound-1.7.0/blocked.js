(function () {
  'use strict';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[<>&"]/g, c => ({
      '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;'
    })[c]);
  }

  function sendBg(msg) {
    try { return chrome.runtime.sendMessage(msg).catch(() => null); }
    catch { return Promise.resolve(null); }
  }

  var params = new URLSearchParams(location.search);
  if (params.get('reason') === 'user-blocklist') {
    var host = params.get('host') || 'this domain';
    document.getElementById('titleText').textContent = 'Domain Blocked';
    document.getElementById('introText').innerHTML =
      'You manually added <strong>' + esc(host) + '</strong> to your blocklist in Corsair Unbound.';
    document.getElementById('reasonText').textContent =
      'This domain is on your personal blocklist. All navigation to it is stopped, from any page or link.';
    document.getElementById('hintText').textContent =
      'Changed your mind? Open the Corsair dashboard → Blocked Domains, and click Unblock.';
  }

  document.getElementById('escapeBtn').addEventListener('click', async () => {
    var btn = document.getElementById('escapeBtn');
    btn.disabled = true;
    btn.textContent = '…';
    await sendBg({ type: 'blocked-page-escape' });
    // Failsafe: if the background never responds or the tab wasn't
    // updated, fall back to a plain history walk.
    setTimeout(() => {
      try {
        if (history.length > 1) history.back();
        else location.replace('about:blank');
      } catch {}
    }, 400);
  });

  document.getElementById('dashboardBtn').addEventListener('click', () => {
    try {
      chrome.runtime.sendMessage({ type: 'open-dashboard' }).catch(() => {});
    } catch {}
    // Belt-and-braces — the background may not have a handler, so navigate
    // the tab directly.
    setTimeout(() => {
      try {
        location.href = chrome.runtime.getURL('dashboard.html');
      } catch {}
    }, 200);
  });
})();