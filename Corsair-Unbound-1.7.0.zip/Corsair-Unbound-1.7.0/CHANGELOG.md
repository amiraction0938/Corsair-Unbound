# Changelog

## [1.7.0]

### Added
- **Multi-language interface** (`core/i18n.js`) — full UI translation for English, فارسی, العربية, Español, Deutsch, Français, Русский and 中文, with automatic RTL layout for Persian and Arabic and a language switcher in the dashboard
- **In-extension update checker** (`core/updater.js`) — periodic check of the GitHub repo's `manifest.json`, desktop notification when a newer version is published, one-click ZIP download, and an in-dashboard "About" panel + install-guide modal explaining the manual reload step (MV3 extensions cannot self-replace their files; existing local data survives the reload)
- **`content-frame-guard.js`** — a new, minimal content script that runs in every frame on the page, including third-party ad/tracker iframes, at `document_start`. It intercepts `window.open()` calls and popup-shaped links at the earliest possible point, before ad-slot scripts can act on them

### Changed
- Navigation containment split across two content scripts: `content-frame-guard.js` (all frames, interception only, no DOM/network work) and `content.js` (top frame only, banners/observation/scanning) — avoids re-running banner and scanning logic once per ad iframe on pages with many embedded frames
- `manifest.json` — version bumped to 1.7.0; added a second `content_scripts` entry (`content-frame-guard.js`, `all_frames: true`, `run_at: document_start`)
- Dashboard sidebar/header gained a language switcher and an "About" section showing current vs. latest version

## [1.5.0] — 2025

### Added
- **Heuristic Analysis Engine** (`core/heuristics.js`)
  - Typosquatting detection (digit substitution, hyphens, Levenshtein distance)
  - Suspicious TLD list (Freenom, `.top`, `.xyz`, `.zip`, etc.)
  - Homograph attack detection (mixed scripts)
  - Punycode / IDN detection
  - Recently-registered domain detection (from VT)
  - Brand-in-subdomain detection
- **Alarm-based TTL** (`core/alarms.js`) — replaces unreliable `setTimeout`
  - Fortress-allow rule expiry now survives service worker restarts
  - Scheduled whitelist sync (weekly)
  - Scheduled cache cleanup (every 6 hours)
- **Extension Badge** — colored icon per tab (green/yellow/red/blue)
- **Trust Button** on verdict banner — one-click whitelist
- **User Trusted Domains** — separate list from safe-scanned cache
- **Download Guard** — blocks downloads from malicious sources
- **Keyboard Shortcuts** (`Ctrl+Shift+F`, `Ctrl+Shift+E`)
- **Dashboard: Search + Bulk actions** for safe-scanned domains
- **Dashboard: Theme Toggle** (light/dark)
- **Dashboard: Privacy & Data panel** — storage usage + wipe-all
- **Export/Import separate Safe List** (as `.json`)
- **Incognito mode** — split mode
- **2-second auto-dismiss** for all in-page banners (except VT loading)
- `README.md`, `LICENSE`, `CHANGELOG.md`

### Changed
- Version bumped from 1.4.0 to 1.5.0
- `manifest.json` — added `alarms` permission, `commands`, `incognito: split`
- Dashboard header — removed top-level Export/Import (moved to Backup section)
- Safe-scanned domains panel moved above guide
- Behavior Intelligence and Evidence Store moved above Domain Profiles
- Network Observation panel moved to bottom

### Fixed
- Fortress-allow TTL now survives service worker restarts
- Settings defaults now consistently applied on first install
- `maxRedirectHops` now respects dashboard setting
- Popup auto-dismiss timing unified at 3 seconds

## [1.4.0]
- Fortress catch-all with DNR session rules
- VT BYOK integration
- Smart whitelist (Cisco OpenDNS)
- Auto threat scan
- Domain analyzer dashboard

## [1.3.0]
- Fortress popup lockdown
- Redirect storm containment
- Auto-scan with notifications

## [1.2.0]
- Initial deterministic DNR enforcement
- Redirect chain tracking

## [1.1.0]
- First public release
