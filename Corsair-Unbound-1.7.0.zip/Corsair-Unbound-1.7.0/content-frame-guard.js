(function () {
  'use strict';

  // This script runs in EVERY frame (all_frames: true) — including
  // third-party ad/tracker iframes, which is exactly where malicious
  // window.open() calls and popup-shaped links usually originate. It
  // intentionally does nothing but intercept — no DOM banners, no page
  // scanning, no network calls beyond a tiny fortress-state read. All of
  // that UI/observation work lives in content.js, which only runs in the
  // top frame (all_frames: false) so it doesn't get triggered once per
  // ad slot on the page.

  let _fortressArmed = false;
  let _fortressChecked = false;
  let _selfHost = '';
  try { _selfHost = String(location.hostname || '').toLowerCase(); } catch {}

  async function refreshFortressState() {
    try {
      const res = await chrome.storage.local.get('domainProfiles');
      const profiles = res?.domainProfiles || {};
      const p = profiles[_selfHost];
      _fortressArmed = Boolean(p && p.protected === true && p.mode === 'fortress');
    } catch {}
    _fortressChecked = true;
  }

  try {
    refreshFortressState();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.domainProfiles) refreshFortressState();
    });
  } catch {}

  function isSameHost(host) {
    const h = String(host || '').toLowerCase();
    if (!h) return false;
    return h === _selfHost || h.endsWith('.' + _selfHost);
  }

  function sendBg(msg) {
    try { return chrome.runtime.sendMessage(msg).catch(() => null); }
    catch { return Promise.resolve(null); }
  }

  /* ============================================================
     SAFE REDIRECT RESOLVER — skips known redirector URL patterns
     (?url=, ?redirect=, etc.) straight to their real target. Runs
     per-frame since each frame navigates independently.
     ============================================================ */
  const REDIRECTOR_PATH_REGEX =
    /\/(?:url|out|redirect|redir|link|click|goto|jump|track|gateway|away|external|safelink)(?:\/|\.[a-z0-9]+|$)/i;
  const REDIRECT_PARAM_KEYS = [
    'url','target','dest','destination','redirect','redirect_url','redirect_uri',
    'redir','u','link','to','next','return','return_url','r','q','goto'
  ];

  function isSafeWebScheme(rawUrl) {
    if (!rawUrl || typeof rawUrl !== 'string') return false;
    try {
      const u = new URL(rawUrl);
      return u.protocol === 'http:' || u.protocol === 'https:';
    } catch { return false; }
  }

  function iterativelyDecodeUrl(raw) {
    if (!raw || typeof raw !== 'string') return '';
    let current = raw.trim();
    for (let i = 0; i < 3; i++) {
      try {
        const decoded = decodeURIComponent(current);
        if (decoded === current) break;
        current = decoded;
      } catch { break; }
    }
    return current;
  }

  function resolveRedirectTarget() {
    if (!window.location || !window.location.href) return null;
    let currentUrl;
    try { currentUrl = new URL(window.location.href); } catch { return null; }
    const pathname = currentUrl.pathname || '';
    if (!REDIRECTOR_PATH_REGEX.test(pathname)) return null;
    const params = currentUrl.searchParams;
    if (!params) return null;
    for (const key of REDIRECT_PARAM_KEYS) {
      const val = params.get(key);
      if (!val) continue;
      const decoded = iterativelyDecodeUrl(val);
      if (!isSafeWebScheme(decoded)) continue;
      try {
        const parsedTarget = new URL(decoded);
        if (parsedTarget.href === currentUrl.href) continue;
        return parsedTarget.href;
      } catch { continue; }
    }
    return null;
  }

  try {
    if (!_fortressArmed) {
      const target = resolveRedirectTarget();
      if (target && typeof window.location.replace === 'function') {
        window.location.replace(target);
        return;
      }
    }
  } catch {}

  /* ============================================================
     POPUP GUARD — overrides window.open() in THIS frame's realm.
     ============================================================ */
  (function installPopupGuard() {
    try {
      const originalOpen = window.open;
      window.open = function (url, name, features) {
        const isSuspiciousShape = (!name || /^_blank$/i.test(String(name))) &&
          /(?:left|top|width|height|resizable)/i.test(String(features || ''));

        if (_fortressArmed) {
          sendBg({
            type: 'content-popup-blocked',
            url: String(url || 'about:blank'),
            page: String(location.href || ''),
            host: _selfHost,
            reason: 'fortress-popup-lockdown'
          });
          console.warn('[Corsair Shield] Fortress armed — popup blocked:', url);
          return null;
        }

        if (!_fortressChecked && isSuspiciousShape) {
          sendBg({
            type: 'content-popup-blocked',
            url: String(url || 'about:blank'),
            page: String(location.href || ''),
            host: _selfHost,
            reason: 'unchecked-suspicious-popup'
          });
          return null;
        }

        return originalOpen.apply(this, arguments);
      };
    } catch {}
  })();

  /* ============================================================
     CLICK INTERCEPTION
     ============================================================ */
  document.addEventListener('click', function (e) {
    if (!_fortressArmed) return;
    const anchor = e.target && e.target.closest && e.target.closest('a');
    if (!anchor) return;

    const target = String(anchor.target || '').toLowerCase();
    const rel = String(anchor.rel || '').toLowerCase();
    const looksLikePopup = target === '_blank' || target === '_new' || rel.includes('noopener') || rel.includes('noreferrer');

    const href = String(anchor.href || '');
    let destHost = '';
    try {
      const u = new URL(href);
      if (u.protocol === 'http:' || u.protocol === 'https:') destHost = u.hostname.toLowerCase();
    } catch {}

    if (looksLikePopup) {
      e.preventDefault();
      e.stopPropagation();
      sendBg({
        type: 'content-popup-blocked',
        url: href,
        page: String(location.href || ''),
        host: _selfHost,
        reason: 'fortress-anchor-popup'
      });
      return;
    }

    if (destHost && !isSameHost(destHost)) {
      sendBg({
        type: 'content-link-allow',
        source: _selfHost,
        destination: destHost,
        page: String(location.href || '')
      });
    }
  }, true);

  document.addEventListener('auxclick', function (e) {
    if (e.button !== 1) return;
    if (!_fortressArmed) return;
    const anchor = e.target && e.target.closest && e.target.closest('a');
    if (!anchor) return;
    e.preventDefault();
    e.stopPropagation();
    sendBg({
      type: 'content-popup-blocked',
      url: String(anchor.href || ''),
      page: String(location.href || ''),
      host: _selfHost,
      reason: 'fortress-middle-click'
    });
  }, true);

  /* ============================================================
     META REFRESH GUARD
     ============================================================ */
  (function installMetaRefreshGuard() {
    function isExternalUrl(raw) {
      try {
        const u = new URL(raw, location.href);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
        return !isSameHost(u.hostname);
      } catch { return false; }
    }

    function processNode(node) {
      if (!node || node.nodeType !== 1) return;
      if (node.tagName !== 'META') return;
      const httpEquiv = (node.getAttribute('http-equiv') || '').toLowerCase();
      if (httpEquiv !== 'refresh') return;
      const content = node.getAttribute('content') || '';
      const m = content.match(/url\s*=\s*(.+)$/i);
      if (m && isExternalUrl(m[1].trim().replace(/^['"]|['"]$/g, ''))) {
        node.remove();
        console.warn('[Corsair Shield] removed external meta refresh');
      }
    }

    try {
      const mo = new MutationObserver(muts => {
        for (const m of muts) {
          for (const n of m.addedNodes || []) processNode(n);
        }
      });
      const target = document.documentElement || document;
      mo.observe(target, { childList: true, subtree: true });
      document.querySelectorAll('meta[http-equiv="refresh"]').forEach(processNode);
    } catch {}
  })();
})();
